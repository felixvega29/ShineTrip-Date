/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecshinetrip;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

/**
 *
 * @author VALENTINA
 */
public class Update {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException {
         String usuario = "root";
         String password = "";
         String url = "jdbc:mysql://localhost:3306/shinetrip";
         Connection conexion;
         Statement statement;
         ResultSet rs;
         
          // Sentencia SQL para la actualización
          String sql = "UPDATE USUARIOS SET NOMBRE = ? WHERE NOMBRE = ?";

          // Nuevos valores a actualizar
          String nuevoValorNombre = "Alex";
          String valorNombre = "ABC";
          
         try { 
         Class.forName("com.mysql.cj.jdbc.Driver");
        
            
          conexion = DriverManager.getConnection(url,usuario,password);
          statement = conexion.createStatement();

            // Preparar la consulta de actualización
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, nuevoValorNombre);
            preparedStatement.setString(2, valorNombre);

            // Ejecutar la actualización
            int filasActualizadas = preparedStatement.executeUpdate();

            // Verificar el resultado
            if (filasActualizadas > 0) {
                System.out.println("Datos actualizados correctamente.");
            } else {
                System.out.println("No se encontraron datos para actualizar.");
            }

            // Cerrar recursos
            preparedStatement.close();
            conexion.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}