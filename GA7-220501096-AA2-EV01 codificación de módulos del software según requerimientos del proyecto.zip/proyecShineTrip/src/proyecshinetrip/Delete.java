/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecshinetrip;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author VALENTINA
 */
public class Delete {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          String usuario = "root";
         String password = "";
         String url = "jdbc:mysql://localhost:3306/shinetrip";
         Connection conexion;
         Statement statement;
         ResultSet rs;
         
         
         try { 
         Class.forName("com.mysql.cj.jdbc.Driver");
        
            
          conexion = DriverManager.getConnection(url, usuario, password);
          statement = conexion.createStatement();
          
          //VALUES
          statement.executeUpdate("DELETE FROM USUARIOS WHERE NOMBRE = 'ABC'");
          
          rs = statement.executeQuery("SELECT * FROM USUARIOS");
          
          //Bloque do-while dentro del bloque try
          rs.next();
          do {
            System.out.println(rs.getInt("ID_USUARIO") + ":" + rs.getNString("NOMBRE") + ":" + rs.getInt("DOCUMENTO") + ":" + rs.getNString("CORREO")+ ":" +rs.getInt("CELULAR") + ":" + rs.getNString("DIRECCION") + ":" +rs.getNString("CIUDAD") + ":" + rs.getNString("PAIS"));
          } while (rs.next());
          
          
}catch (ClassNotFoundException | SQLException ex){
    ex.printStackTrace();
}
}
}
